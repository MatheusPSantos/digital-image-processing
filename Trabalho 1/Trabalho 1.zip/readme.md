## Trabalho 1

Aluno: Matheus Pereira dos Santos<br>
Curso: Engenharia da Computação<br>
Ano: 2022/1<br>

### Especificação do Problema
Escreva um programa para transformar uma imagem de níveis de cinza na qual cada pixel é
representado por 8 bits (256 níveis de cinza), conforme as seguintes operações:

a) inverter os valores de intensidade da imagem, tal que o valor 255 passa a ser 0, 254 passa a ser 1,
assim por diante;

b) os valores de intensidade da imagem presentes nas colunas pares são trocados com os valores de
intensidade das colunas ímpares;

c) os valores de intensidade da imagem presentes nas linhas pares são trocados com os valores de
intensidade das linhas ímpares;

d) realizar o processo de alargamento de contraste (histogram strechting).

# Forma de executar o programa

Pode ser executado usando o Jupyter Notebook ou através do script `programa.py`.
